Instructions:
- Run the server and client (in no particular order)
- The server and client must be running on the same machine
- Remember to run server first before you log in the client

Notes:
- User can enter IP Address of SERVER once program starts
- CLIENT sends position updates (UDP) to the SERVER
    - CLIENTs update the position of both local and remote objects
- Chat function does not work
    - TCP connection works but did not have time to add code for chat
- SERVER displays IP Addresses of connected clients
    - Server also displays all traffic messages to console
- SERVER code to handle voluntary disconnections is incomplete
- CLIENTs and SERVER do not suspend execution while waiting for data

*Done in pair
Members:
100748771 - Mrinank Sivakumar
100752265 - Kimberly Hansuwan